package show;

public interface Showable {
	public void showAll();

}
